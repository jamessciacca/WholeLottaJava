var h1 = document.querySelector('h1');
var button = document.querySelector('button');
var body = document.body;
var darkModeActive = false;

h1.innerText = 'JS HardMode';


//create a variable that tracks if darkmode is on!
//if variable is true switch to light if false switch to dark


button.addEventListener('click', function(){
    if (darkModeActive === false){
        body.classList.add('darkmode')
        button.innerText = 'Light Mode'
        darkModeActive = true;
    }else{
        body.classList.remove('darkmode')
        button.innerText = 'Dark Mode'
        darkModeActive = false;
    }
    
});





// // example function to see how it works!
// function newStuff(num, str, whatAmI){
//     //the name of the function does not matter!
//     whatAmI('make me console out... tricky tricky.');
// }
//                     //function references the argument
//                     //the name doesn't matter!!!!!!!!!
// newStuff(10, 'some string', function(someVal){
    
//     console.log(someVal)

// });


